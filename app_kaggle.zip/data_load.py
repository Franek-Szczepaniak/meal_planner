import pandas as pd
import glob
import os
import ast
import re
import json
import difflib
import html # <--- NOWY IMPORT DO DEKODOWANIA UŁAMKÓW HTML

# --- KONFIGURACJA WYŚWIETLANIA W TERMINALU ---
pd.set_option('display.max_columns', None)      
pd.set_option('display.max_rows', 10)          
pd.set_option('display.width', 1000)            

data_dir = '.'

print("1. Ładowanie i łączenie baz odżywczych...")
nutrition_files = glob.glob(os.path.join(data_dir, 'FOOD-DATA-GROUP*.csv'))
nutrition_dfs = [pd.read_csv(file) for file in nutrition_files]
nutrition_df = pd.concat(nutrition_dfs, ignore_index=True)
nutrition_df.drop_duplicates(inplace=True)

SAMPLE_SIZE = 10000
print(f"2. Wczytywanie i losowanie próbki {SAMPLE_SIZE} przepisów...")
recipes_df = pd.read_csv(os.path.join(data_dir, 'recipes_data.csv')).sample(n=SAMPLE_SIZE, random_state=42)

# --- PRZYGOTOWANIE BAZY ODŻYWCZEJ DO SZYBKIEGO WYSZUKIWANIA ---
print("3. Tworzenie słownika wartości odżywczych (lookup table)...")
nutrition_lookup = {}
for _, row in nutrition_df.iterrows():
    food_name = str(row['food']).strip().lower()
    nutrition_lookup[food_name] = {
        'kcal': row['Caloric Value'],
        'protein': row['Protein'],
        'fat': row['Fat'],
        'carbs': row['Carbohydrates'],
        'fiber': row['Dietary Fiber'],
        'sodium': row['Sodium'],
        'iron': row['Iron']
    }

# --- FUNKCJE POMOCNICZE I SŁOWNIKI JEDNOSTEK ---

UNIT_MAPPING = {
    'c.': 'cup', 'c': 'cup', 'cup': 'cup', 'cups': 'cup',
    'tsp.': 'tsp', 'tsp': 'tsp', 'teaspoon': 'tsp', 'teaspoons': 'tsp', 't.': 'tsp',
    'tbsp.': 'tbsp', 'tbsp': 'tbsp', 'tablespoon': 'tbsp', 'tablespoons': 'tbsp', 'T.': 'tbsp',
    'oz.': 'oz', 'oz': 'oz', 'ounce': 'oz', 'ounces': 'oz',
    'g': 'g', 'g.': 'g', 'gram': 'g', 'grams': 'g',
    'kg': 'kg', 'kilogram': 'kg',
    'lb': 'lb', 'lbs': 'lb', 'pound': 'lb', 'pounds': 'lb',
    'ml': 'ml', 'l': 'l',
    'pinch': 'pinch', 'dash': 'pinch',
    'clove': 'clove', 'cloves': 'clove',
    'slice': 'slice', 'slices': 'slice',
    'package': 'package', 'pkg': 'package',
    'can': 'can', 'cans': 'can',
    'jar': 'jar'
}

TO_GRAMS = {
    'g': 1.0, 'kg': 1000.0, 'ml': 1.0, 'l': 1000.0,
    'cup': 240.0, 'tbsp': 15.0, 'tsp': 5.0, 'oz': 28.35,
    'lb': 453.59, 'pinch': 0.5, 'clove': 5.0, 'slice': 20.0,
    'package': 250.0, 'can': 400.0, 'jar': 300.0, 'pc': 150.0   
}

def parse_list_string(string_list):
    try:
        return ast.literal_eval(string_list)
    except (ValueError, SyntaxError):
        return []

def extract_quantity_and_unit(raw_ingredient_str):
    """Wyciąga wartość numeryczną (w tym ułamki) oraz jednostkę z surowego stringa."""
    qty = 1.0
    
    # KROK 1: Odkodowanie encji HTML (Naprawia problem &frac12; -> 12)
    s = html.unescape(raw_ingredient_str).lower()
    
    # Zamiana znaków ułamkowych Unicode na zwykłe liczby ułatwiające parsowanie
    unicode_fractions = {
        '½': '0.5', '⅓': '0.33', '⅔': '0.67', '¼': '0.25', '¾': '0.75',
        '⅕': '0.2', '⅖': '0.4', '⅗': '0.6', '⅘': '0.8', '⅙': '0.17',
        '⅚': '0.83', '⅛': '0.125', '⅜': '0.375', '⅝': '0.625', '⅞': '0.875'
    }
    for char, val in unicode_fractions.items():
        s = s.replace(char, f" {val} ")
        
    # Wyciąganie ilości (Obsługuje formaty: "1/2", "1 1/4" itp.)
    fraction_match = re.search(r'(?:(\d+)\s+)?(\d+)\s*\/\s*(\d+)', s)
    if fraction_match:
        whole = float(fraction_match.group(1)) if fraction_match.group(1) else 0.0
        num = float(fraction_match.group(2))
        den = float(fraction_match.group(3))
        if den != 0:
            qty = whole + (num / den)
    else:
        number_match = re.search(r'(\d+\.?\d*)', s)
        if number_match:
            qty = float(number_match.group(1))
            
    # Wyciąganie jednostki
    found_unit = "pc"  
    words = re.findall(r'[a-zA-Z\.]+', s)
    for word in words:
        if word in UNIT_MAPPING:
            found_unit = UNIT_MAPPING[word]
            break 
            
    return round(qty, 2), found_unit


# --- 4. GŁÓWNA PĘTLA TRANSFORMACJI ---
print("4. Transformacja przepisów i inteligentne łączenie z bazą odżywczą...")
processed_recipes = []

# Sortujemy listę bazy odżywczej od najdłuższej nazwy do najkrótszej (bardzo ważne!)
known_foods = sorted(list(nutrition_lookup.keys()), key=len, reverse=True)

def find_best_match(ingredient_name, options):
    if ingredient_name in options:
        return ingredient_name
        
    for opt in options:
        # Szybkie sprawdzenie, czy w ogóle jest podobieństwo
        if opt in ingredient_name or ingredient_name in opt:
            # Wymuszenie pełnego słowa (\b) – zapobiega łapaniu "salt" z "unsalted"
            if re.search(rf'\b{re.escape(opt)}\b', ingredient_name) or re.search(rf'\b{re.escape(ingredient_name)}\b', opt):
                return opt
                
    matches = difflib.get_close_matches(ingredient_name, options, n=1, cutoff=0.75)
    if matches:
        return matches[0]
    return None

for index, row in recipes_df.iterrows():
    if index % 100 == 0:
        print(f"Przetwarzanie wiersza: {index}...")
        
    recipe_id = f"rec_{index}"
    title = row['title']
    
    raw_ingredients = parse_list_string(row['ingredients'])
    ner_ingredients = parse_list_string(row['NER'])
    
    total_kcal = total_protein = total_fat = total_carbs = total_fiber = total_sodium = 0
    mapped_ingredients = {}
    
    for raw_str in raw_ingredients:
        qty, unit = extract_quantity_and_unit(raw_str)
        
        matched_ner = None
        for ner in sorted(ner_ingredients, key=len, reverse=True):
            if ner.lower() in raw_str.lower():
                matched_ner = ner.lower()
                break
                
        if matched_ner:
            matched_food = find_best_match(matched_ner, known_foods)
            
            if matched_food and matched_food not in mapped_ingredients:
                mapped_ingredients[matched_food] = {"qty": qty, "unit": unit}
                
                db_item = nutrition_lookup[matched_food]
                weight_in_grams = qty * TO_GRAMS.get(unit, 1.0)
                multiplier = weight_in_grams / 100.0 
                
                total_kcal += db_item['kcal'] * multiplier
                total_protein += db_item['protein'] * multiplier
                total_fat += db_item['fat'] * multiplier
                total_carbs += db_item['carbs'] * multiplier
                total_fiber += db_item['fiber'] * multiplier
                total_sodium += db_item['sodium'] * multiplier

    if len(mapped_ingredients) >= 5 and 10000 >= total_kcal > 100:
        processed_recipes.append({
            "id": recipe_id,
            "name": title,
            "link": str(row.get('link', '')),
            "kcal": round(total_kcal, 2),
            "macros": {
                "protein": round(total_protein, 2),
                "fat": round(total_fat, 2),
                "carbs": round(total_carbs, 2),
            },
            "micros": {
                "fiber": round(total_fiber, 2),
                "sodium": round(total_sodium, 2)
            },
            "ingredients": mapped_ingredients
        })

print(f"Udało się zmapować i przetworzyć {len(processed_recipes)} z {SAMPLE_SIZE} wylosowanych przepisów.")

# --- ZAPIS DO PLIKU ---
output_file = 'algorithm_input_data.json'
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(processed_recipes, f, ensure_ascii=False, indent=4)

print(f"\nGotowe! Plik wejściowy dla algorytmu zapisano jako: {output_file}")