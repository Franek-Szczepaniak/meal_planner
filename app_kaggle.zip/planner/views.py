from django.shortcuts import render
from django.conf import settings
import json
import os
from .greedy import greedy_meal_planner_advanced
from .aco import aco_meal_planner # Dodajemy import mrówkowego

# --- PRZELICZNIKI JEDNOSTEK NA GRAMY ---
TO_GRAMS = {
    'g': 1.0, 'kg': 1000.0, 'ml': 1.0, 'l': 1000.0,
    'cup': 240.0, 'tbsp': 15.0, 'tsp': 5.0, 'oz': 28.35,
    'lb': 453.59, 'pinch': 0.5, 'clove': 5.0, 'slice': 20.0,
    'package': 250.0, 'can': 400.0, 'jar': 300.0, 'pc': 150.0
}

def index(request):
    json_path = os.path.join(settings.BASE_DIR, 'algorithm_input_data.json')
    with open(json_path, 'r', encoding='utf-8') as f:
        recipes = json.load(f)

    # 1. Budowanie listy składników i mapowania na jednostki
    all_ingredients = set()
    ingredient_units = {}
    
    for r in recipes:
        for ing_name, ing_data in r['ingredients'].items():
            all_ingredients.add(ing_name)
            if isinstance(ing_data, dict):
                ingredient_units[ing_name] = ing_data.get('unit', 'pc')
            else:
                ingredient_units[ing_name] = 'pc'
                
    all_ingredients = sorted(list(all_ingredients))

    # Default goal values
    target_kcal = 2400
    target_pro = 160
    target_fat = 80
    target_carb = 260
    
    my_fridge = {}           # Lodówka w GRAMACH (dla algorytmów)
    initial_fridge_raw = {}  # Lodówka w oryginalnych jednostkach (dla UI)
    selected_algo = 'greedy'
    
    # Default weights (initial)
    weight_waste = 5
    weight_kcal = 5
    weight_macro = 5
    
    planned_schedule = []
    leftovers = {}

    if request.method == 'POST':
        target_kcal = float(request.POST.get('target_kcal', 2400))
        target_pro = float(request.POST.get('target_pro', 160))
        target_fat = float(request.POST.get('target_fat', 80))
        target_carb = float(request.POST.get('target_carb', 260))
        selected_algo = request.POST.get('algorithm', 'greedy')
        
        # Pobranie wag z formularza
        weight_waste = int(request.POST.get('weight_waste', 5))
        weight_kcal = int(request.POST.get('weight_kcal', 5))
        weight_macro = int(request.POST.get('weight_macro', 5))
        
        ing_names = request.POST.getlist('ing_name[]')
        ing_qtys = request.POST.getlist('ing_qty[]')
        
        # 2. Przeliczanie wprowadzonych ilości na GRAMY
        for name, qty in zip(ing_names, ing_qtys):
            if name and qty:
                qty_float = float(qty)
                initial_fridge_raw[name] = qty_float  # Zapisujemy to, co wpisał user
                
                unit = ingredient_units.get(name, 'pc')
                # Obliczamy gramy dla algorytmu
                my_fridge[name] = qty_float * TO_GRAMS.get(unit, 1.0)

        if selected_algo == 'aco':
            planned_schedule, leftovers = aco_meal_planner(
                recipes, my_fridge, target_kcal, target_pro, target_fat, target_carb,
                weight_waste=weight_waste, weight_kcal=weight_kcal, weight_macro=weight_macro
            )
        else:
            planned_schedule, leftovers = greedy_meal_planner_advanced(
                recipes, my_fridge, target_kcal, target_pro, target_fat, target_carb,
                weight_waste=weight_waste, weight_kcal=weight_kcal, weight_macro=weight_macro
            )
            
        # 3. Formatowanie lodówki do wyświetlenia w interfejsie (obiekty z jednostkami)
        initial_fridge = [
            {'name': name, 'qty': qty, 'unit': ingredient_units.get(name, 'pc')}
            for name, qty in initial_fridge_raw.items()
        ]
        
        # 4. Formatowanie resztek: zamiana z gramów z powrotem na oryginalne jednostki dla UI
        leftovers_formatted = []
        for name, qty_in_grams in leftovers.items():
            unit = ingredient_units.get(name, 'pc')
            original_qty = qty_in_grams / TO_GRAMS.get(unit, 1.0)
            
            leftovers_formatted.append({
                'name': name, 
                'qty': round(original_qty, 1), 
                'unit': unit
            })
            
    else:
        initial_fridge = []
        leftovers_formatted = []

    total_kcal = sum(meal['kcal'] for meal in planned_schedule)
    days_planned = len(planned_schedule) / 3 
    avg_kcal = round(total_kcal / days_planned, 1) if days_planned > 0 else 0

    context = {
        'schedule': planned_schedule,
        'initial_fridge': initial_fridge,
        'leftovers': leftovers_formatted,
        'avg_kcal': avg_kcal,
        'target_kcal': target_kcal,
        'target_pro': target_pro,
        'target_fat': target_fat,
        'target_carb': target_carb,
        'all_ingredients': all_ingredients,
        'selected_algo': selected_algo,
        'weight_waste': weight_waste,
        'weight_kcal': weight_kcal,
        'weight_macro': weight_macro,
        'ingredient_units': ingredient_units, # Mapowanie dla JavaScriptu w szablonie
    }
    
    return render(request, 'planner/index.html', context)